tinyMCEPopup.requireLangPack();

var UnlCalendarDisplayDialog = {

	init : function() {
		var selection = tinyMCEPopup.editor.selection;
		var node = selection.getNode();
		if (node && node.id == 'wdn_calendarDisplay') {
			var matches = selection.getContent().match(/UNLevent_monthWidget\.init\(([^)]*)\)/i);
			var calendarUri = matches[1].substr(1, matches[1].length - 2);
			document.getElementById('unlEventUri').value = calendarUri;
			UnlCalendarDisplayDialog.calendarUri = calendarUri;
		}

		document.getElementById('unlEventCalendarDisplayForm').onsubmit = UnlCalendarDisplayDialog.submit;
	},

	submit : function() {
		var selection = tinyMCEPopup.editor.selection;
		var eventName = document.getElementById('unlEventName').value;
		var eventUri = document.getElementById('unlEventUri').value;
		var eventLimit = document.getElementById('unlEventLimit').value;
		var node = selection.getNode();
		
		if (node && node.id == 'wdn_calendarDisplay') {
			var html = selection.getContent()
			selection.setContent(html.replace(UnlCalendarDisplayDialog.calendarUri, eventUri));
		} else {
			selection.setContent("<div id=\"wdn_calendarDisplay\"><script type=\"text/javascript\">WDN.initializePlugin('events', function(){WDN.events.calTitle = \"" + eventName + "\";WDN.events.calURL = \"" + eventUri + "\";WDN.events.limit=" + eventLimit + ";WDN.events.initialize();});</script></div>");
		}
		
		tinyMCEPopup.close();
		return false;
	},
	
	calendarUri : ''
};

tinyMCEPopup.onInit.add(UnlCalendarDisplayDialog.init, UnlCalendarDisplayDialog);
